import matplotlib.pyplot as plt

test_var = {"A": {"AA": 10}, "B": {"BB": 100}}
plt.imshow(test_var)
plt.show()